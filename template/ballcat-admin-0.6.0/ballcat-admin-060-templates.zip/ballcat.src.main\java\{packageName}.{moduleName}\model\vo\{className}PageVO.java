package ${packageName}.${moduleName}.model.vo;

import io.swagger.v3.oas.annotations.media.Schema;

import lombok.Data;
#if(${hasBigDecimal})
import java.math.BigDecimal;
#end
import java.time.LocalDateTime;

/**
 * ${comments}分页视图对象
 *
 * @author ${author} ${currentTime}
 */
@Data
@Schema(title = "${comments}分页视图对象")
public class ${className}PageVO {
    private static final long serialVersionUID = 1L;

#foreach ($column in $columns)
    /**
     * $column.comments
     */
    @Schema(title="$column.comments")
    private $column.attrType $column.attrName;
    
#end

}