package ${packageName}.${moduleName}.mapper;

import com.baomidou.mybatisplus.core.metadata.IPage;
import ${packageName}.${moduleName}.converter.${className}Converter;
import ${packageName}.${moduleName}.model.entity.${className};
import ${packageName}.${moduleName}.model.qo.${className}QO;
import ${packageName}.${moduleName}.model.vo.${className}PageVO;
import com.hccake.ballcat.common.model.domain.PageParam;
import com.hccake.ballcat.common.model.domain.PageResult;
import com.hccake.extend.mybatis.plus.conditions.query.LambdaQueryWrapperX;
import com.hccake.extend.mybatis.plus.mapper.ExtendMapper;
import com.hccake.extend.mybatis.plus.toolkit.WrappersX;

/**
 * ${comments}
 *
 * @author ${author} ${currentTime}
 */
public interface ${className}Mapper extends ExtendMapper<${className}> {

    /**
    * 分页查询
    * @param pageParam 分页参数
    * @param qo 查询参数
    * @return PageResult<${className}PageVO> VO分页数据
    */
   default PageResult<${className}PageVO> queryPage(PageParam pageParam, ${className}QO qo){
		IPage<${className}> page = this.prodPage(pageParam);
		LambdaQueryWrapperX<${className}> wrapper = WrappersX.lambdaQueryX(${className}.class);
		this.selectPage(page, wrapper);
		IPage<${className}PageVO> voPage = page.convert(${className}Converter.INSTANCE::poToPageVo);
		return new PageResult<>(voPage.getRecords(), voPage.getTotal());
   }
}