package ${packageName}.${moduleName}.converter;

import ${packageName}.${moduleName}.model.entity.${className};
import ${packageName}.${moduleName}.model.vo.${className}PageVO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

/**
 * ${comments}模型转换器
 *
 * @author ${author} ${currentTime}
 */
@Mapper
public interface ${className}Converter {

	${className}Converter INSTANCE = Mappers.getMapper(${className}Converter.class);

	/**
	 * PO 转 PageVO
	 * @param ${classname} ${comments}
	 * @return ${className}PageVO ${comments}PageVO
	 */
	${className}PageVO poToPageVo(${className} ${classname});

}
