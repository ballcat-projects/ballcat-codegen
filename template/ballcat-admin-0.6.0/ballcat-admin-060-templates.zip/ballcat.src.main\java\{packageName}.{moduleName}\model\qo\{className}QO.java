package ${packageName}.${moduleName}.model.qo;

import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;

import lombok.Data;
import org.springdoc.api.annotations.ParameterObject;

/**
 * ${comments} 查询对象
 *
 * @author ${author} ${currentTime}
 */
@Data
@Schema(title = "${comments}查询对象")
@ParameterObject
public class ${className}QO  {
	private static final long serialVersionUID = 1L;

#foreach ($column in $columns)
	/**
	 * $column.comments
	 */
#if($column.columnName == $pk.columnName)
	@Parameter(description="$column.comments")
	private $column.attrType $column.attrName;
#break
#end
#end

}