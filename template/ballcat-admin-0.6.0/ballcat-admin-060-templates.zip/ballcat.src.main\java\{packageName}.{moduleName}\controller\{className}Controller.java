package ${packageName}.${moduleName}.controller;

import ${packageName}.${moduleName}.model.entity.${className};
import ${packageName}.${moduleName}.model.qo.${className}QO;
import ${packageName}.${moduleName}.model.vo.${className}PageVO;
import ${packageName}.${moduleName}.service.${className}Service;
import com.hccake.ballcat.common.log.operation.annotation.CreateOperationLogging;
import com.hccake.ballcat.common.log.operation.annotation.DeleteOperationLogging;
import com.hccake.ballcat.common.log.operation.annotation.UpdateOperationLogging;
import com.hccake.ballcat.common.model.domain.PageParam;
import com.hccake.ballcat.common.model.domain.PageResult;
import com.hccake.ballcat.common.model.result.BaseResultCode;
import com.hccake.ballcat.common.model.result.R;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * ${comments}
 *
 * @author ${author} ${currentTime}
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/${moduleName}/${path}" )
@Tag(name = "${comments}管理")
public class ${className}Controller {

    private final  ${className}Service ${classname}Service;

    /**
     * 分页查询
     * @param pageParam 分页参数
     * @param ${classname}QO ${comments}查询对象
     * @return R 通用返回体
     */
    @Operation(summary = "分页查询")
    @GetMapping("/page" )
    @PreAuthorize("@per.hasPermission('${moduleName}:${path}:read')" )
    public R<PageResult<${className}PageVO>> get${className}Page(
            PageParam pageParam, ${className}QO ${classname}QO) {
        return R.ok(${classname}Service.queryPage(pageParam, ${classname}QO));
    }

    /**
     * 新增${comments}
     * @param ${classname} ${comments}
     * @return R 通用返回体
     */
    @Operation(summary = "新增${comments}")
    @CreateOperationLogging(msg = "新增${comments}" )
    @PostMapping
    @PreAuthorize("@per.hasPermission('${moduleName}:${path}:add')" )
    public R<Void> save(@RequestBody ${className} ${classname}) {
        return ${classname}Service.save(${classname}) ?
                R.ok() : R.failed(BaseResultCode.UPDATE_DATABASE_ERROR, "新增${comments}失败");
    }

    /**
     * 修改${comments}
     * @param ${classname} ${comments}
     * @return R 通用返回体
     */
    @Operation(summary = "修改${comments}")
    @UpdateOperationLogging(msg = "修改${comments}" )
    @PutMapping
    @PreAuthorize("@per.hasPermission('${moduleName}:${path}:edit')" )
    public R<Void> updateById(@RequestBody ${className} ${classname}) {
        return ${classname}Service.updateById(${classname}) ?
                R.ok() : R.failed(BaseResultCode.UPDATE_DATABASE_ERROR, "修改${comments}失败");
    }

    /**
     * 通过id删除${comments}
     * @param ${pk.attrName} id
     * @return R 通用返回体
     */
    @Operation(summary = "通过id删除${comments}")
    @DeleteOperationLogging(msg = "通过id删除${comments}" )
    @DeleteMapping("/{${pk.attrName}}" )
    @PreAuthorize("@per.hasPermission('${moduleName}:${path}:del')" )
    public R<Void> removeById(@PathVariable("${pk.attrName}") ${pk.attrType} ${pk.attrName}) {
        return ${classname}Service.removeById(${pk.attrName}) ?
                R.ok() : R.failed(BaseResultCode.UPDATE_DATABASE_ERROR, "通过id删除${comments}失败");
    }

}