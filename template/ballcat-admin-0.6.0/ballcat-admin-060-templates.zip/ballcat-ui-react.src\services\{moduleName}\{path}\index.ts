import type { PageResult, QueryParam, R } from '@/typings';
import { request } from 'umi';
import type { ${className}, ${className}Qo, ${className}Vo } from './typings';

export * from './typings';

export async function query(body: QueryParam<${className}Qo>) {
  return request<R<PageResult<${className}Vo>>>('${moduleName}/${path}/page', {
    method: 'GET',
    params: body,
  });
}

export async function create(body: ${className}) {
  return request<R<any>>('${moduleName}/${path}', {
    method: 'POST',
    data: body,
  });
}

export async function edit(body: ${className}) {
  return request<R<any>>('${moduleName}/${path}', {
    method: 'PUT',
    data: body,
  });
}
#set($delPk = "body.")
export async function del(body: ${className}Vo) {
  return request<R<any>>(`${moduleName}/${path}/${${delPk}${pk.attrName}}`, {
    method: 'DELETE',
  });
}