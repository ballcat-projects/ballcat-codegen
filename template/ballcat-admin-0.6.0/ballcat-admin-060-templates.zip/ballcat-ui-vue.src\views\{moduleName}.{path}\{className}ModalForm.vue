<template>
  <a-modal
    :title="title"
    :visible="visible"
    :mask-closable="false"
    :body-style="{paddingBottom: '8px'}"
    :confirm-loading="submitLoading"
    @ok="handleSubmit"
    @cancel="handleClose"
  >
    <a-form
      :form="form"
      :label-col="labelCol"
      :wrapper-col="wrapperCol"
    >
#foreach ($column in $columns)
#if($column.columnName == $pk.attrName)
      <a-form-item v-if="isUpdateForm" style="display: none">
        <a-input v-decorator="['${pk.attrName}']" />
      </a-form-item>
#elseif($column.columnName != "create_time" && $column.columnName != "update_time")
      <a-form-item label="$column.comments">
        <a-input v-decorator="['$column.attrName']" placeholder="$column.comments" />
      </a-form-item>
#end
#end
    </a-form>
  </a-modal>
</template>

<script>
import { PopUpFormMixin } from '@/mixins'
import { addObj, putObj } from '@/api/${moduleName}/${path}'

export default {
  name: '${className}ModalForm',
  mixins: [PopUpFormMixin],
  data () {
    return {
      reqFunctions: {
        create: addObj,
        update: putObj
      },

      labelCol: {
        sm: { span: 24 },
        md: { span: 5 }
      },
      wrapperCol: {
        sm: { span: 24 },
        md: { span: 19 }
      },

      // 校验配置
      decoratorOptions: {}
    }
  },
  methods: {}
}
</script>