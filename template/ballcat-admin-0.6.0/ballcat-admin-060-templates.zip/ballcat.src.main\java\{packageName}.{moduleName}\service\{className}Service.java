package ${packageName}.${moduleName}.service;

import ${packageName}.${moduleName}.model.entity.${className};
import ${packageName}.${moduleName}.model.vo.${className}PageVO;
import ${packageName}.${moduleName}.model.qo.${className}QO;
import com.hccake.ballcat.common.model.domain.PageParam;
import com.hccake.ballcat.common.model.domain.PageResult;
import com.hccake.extend.mybatis.plus.service.ExtendService;

/**
 * ${comments}
 *
 * @author ${author} ${currentTime}
 */
public interface ${className}Service extends ExtendService<${className}> {

    /**
    *  根据QueryObeject查询分页数据
    * @param pageParam 分页参数
    * @param qo 查询参数对象
    * @return PageResult&lt;${className}PageVO&gt; 分页数据
    */
    PageResult<${className}PageVO> queryPage(PageParam pageParam, ${className}QO qo);

}