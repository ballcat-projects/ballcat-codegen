## 备注： 变量的使用方法，是mysql语法，基础生成部分是全数据库通用，若数据源非mysql，请只执行基础生成sql
START TRANSACTION;

-- 目录ID
set @pId = 目录ID;
-- 菜单ID
set @menuId = 菜单ID;

## -----------------基础生成部分start-------------
-- 插入菜单
INSERT INTO `sys_menu`
	(`id`, `parent_id`, `title`, `icon`, `permission`, `path`, `target_type`, `uri`, `sort`, `keep_alive`, `hidden`, `type`, `remarks`, `deleted`, `create_time`, `update_time`) 
VALUES 
	(@menuId, @pId, '${comments}', NULL, NULL, '${path}', 1, NULL, 1, 0, 0, 1, NULL, 0, NOW(), NOW());


-- 菜单对应按钮SQL
INSERT INTO `sys_menu`
	(`id`, `parent_id`, `title`, `icon`, `permission`, `path`, `target_type`, `uri`, `sort`, `keep_alive`, `hidden`, `type`, `remarks`, `deleted`, `create_time`, `update_time`) 
VALUES 
	(@menuId + 1, @menuId, '${comments}查询', NULL, '${moduleName}:${path}:read', NULL, 1, NULL, 1, 0, 0, 2, NULL, 0, NOW(), NOW());

INSERT INTO `sys_menu`
	(`id`, `parent_id`, `title`, `icon`, `permission`, `path`, `target_type`, `uri`, `sort`, `keep_alive`, `hidden`, `type`, `remarks`, `deleted`, `create_time`, `update_time`) 
VALUES 
	(@menuId + 2, @menuId, '${comments}新增', NULL, '${moduleName}:${path}:add', NULL, 1, NULL, 2, 0, 0, 2, NULL, 0, NOW(), NOW());


INSERT INTO `sys_menu`
	(`id`, `parent_id`, `title`, `icon`, `permission`, `path`, `target_type`, `uri`, `sort`, `keep_alive`, `hidden`, `type`, `remarks`, `deleted`, `create_time`, `update_time`) 
VALUES 
	(@menuId + 3, @menuId, '${comments}修改', NULL, '${moduleName}:${path}:edit', NULL, 1, NULL, 3, 0, 0, 2, NULL, 0, NOW(), NOW());


INSERT INTO `sys_menu`
	(`id`, `parent_id`, `title`, `icon`, `permission`, `path`, `target_type`, `uri`, `sort`, `keep_alive`, `hidden`, `type`, `remarks`, `deleted`, `create_time`, `update_time`) 
VALUES 
	(@menuId + 4, @menuId, '${comments}删除', NULL, '${moduleName}:${path}:del', NULL, 1, NULL, 4, 0, 0, 2, NULL, 0, NOW(), NOW());
## -----------------基础生成部分end-------------

-- 清空变量
set @menuId = null;
set @pId = null;

COMMIT;