import Page from '@/components/Page';
import type { ProColumns } from '@ant-design/pro-table';
import { ProFormText } from '@ant-design/pro-form';
import * as ${moduleName}${className} from '@/services/${moduleName}/${path}';
import type { ${className}, ${className}Qo, ${className}Vo } from '@/services/${moduleName}/${path}';

const dataColumns: ProColumns<${className}Vo>[] = [
#foreach ($column in $columns)
  {
    title: '$column.comments',
    dataIndex: '$column.attrName',
#if($column.columnName == "create_time" || $column.columnName == "update_time")
    width: '150px',
    sorter: true,
#end
  },
#end
];

export default () => {
  return (
    <Page.Modal<${className}Vo, ${className}Qo, ${className}>
      {...${moduleName}${className}}
      rowKey="${pk.attrName}"
      title="${comments}"
      columns={dataColumns}
      toolBarActions={[{ type: 'create', permission: '${moduleName}:${path}:edit' }]}
      operateBar={[{ type: 'del', permission: '${moduleName}:${path}:del' }]}
    >
#foreach ($column in $columns)
#if($column.columnName == $pk.attrName)
      <ProFormText hidden name="${pk.attrName}" />
#elseif($column.columnName != "create_time" && $column.columnName != "update_time")
      <ProFormText label="$column.comments" name="${column.attrName}" placeholder="请输入${column.comments}" />
#end
#end
    </Page.Modal>
  );
};