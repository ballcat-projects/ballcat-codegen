export type ${className}Qo = {
#foreach ($column in $columns)
  // $column.comments
  $column.attrName: $column.tsAttrType;
#end
}

export type ${className}Vo = {
#foreach ($column in $columns)
  // $column.comments
  $column.attrName: $column.tsAttrType;
#end
}

export type ${className} = {
#foreach ($column in $columns)
  // $column.comments
  $column.attrName: $column.tsAttrType;
#end
}