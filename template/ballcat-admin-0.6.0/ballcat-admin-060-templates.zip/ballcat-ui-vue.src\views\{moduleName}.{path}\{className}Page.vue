<template>
  <div class="ant-pro-page-container-children-content">
  	<pro-table
        ref="table"
        toolbar-title="${comments}"
        :row-key="rowKey"
        :request="tableRequest"
        :columns="columns"
      >
      	<!-- 查询表单 -->
      	<template #search-form="searchFormState">
          <a-row :gutter="16">
            <a-col :md="8" :sm="24">
              <a-form-item label="ID">
                <a-input v-model="searchFormState.queryParam.${pk.attrName}" placeholder="" />
              </a-form-item>
            </a-col>
            <a-col :md="8" :sm="24">
              <a-form-item :wrapper-col="{flex: '1 1 0'}" class="search-actions-wrapper">
                <a-space>
                  <a-button type="primary" :loading="searchFormState.loading" @click="searchFormState.reloadTable(true)">
                    查询
                  </a-button>
                  <a-button @click="searchFormState.resetSearchForm">重置</a-button>
                </a-space>
              </a-form-item>
            </a-col>
          </a-row>
      	</template>
    
    	<!-- 操作按钮区域 -->
      <template #toolbar-action>
         <a-button
            v-has="'${moduleName}:${path}:add'"
            type="primary"
            icon="plus"
            @click="handleAdd()"
          >新建
          </a-button>
      </template>

      <!--表格展示相关插槽-->
      <template #action-slot="text, record">
            <a v-has="'${moduleName}:${path}:edit'" @click="handleEdit(record)">编辑</a>
            <a-divider type="vertical" />
            <a-popconfirm 
            	v-has="'${moduleName}:${path}:del'"
                title="确认要删除吗？"
                @confirm="() => handleDel(record)"
             >
              <a href="javascript:" class="ballcat-text-danger">删除</a>
            </a-popconfirm>
          </template>
	</pro-table>

    <!--表单弹窗-->
    <${path}-modal-form ref="formModal" @reload-page-table="reloadPageTable"/>
  </div>
</template>

<script>
import ProTable from '@/components/Table/ProTable.js'
import { doRequest } from '@/utils/request'
import { getPage, delObj } from '@/api/${moduleName}/${path}'
import ${className}ModalForm from '@/views/${moduleName}/${path}/${className}ModalForm'

export default {
  name: '${className}Page',
  components: { ProTable, ${className}ModalForm },
  data () {
    return {
      rowKey: 'id',
      tableRequest: getPage,

      columns: [
#foreach($column in $columns)
#if($column.columnName != 'create_time' && $column.columnName != 'update_time')
#if($column.columnName == 'id')
        {
          title: '#',
          dataIndex: '$column.attrName'
        },
#else
        {
          title: '$column.comments',
          dataIndex: '$column.attrName'
        },
#end
#end
#end
        {
          title: '创建时间',
          dataIndex: 'createTime',
          width: '150px',
          sorter: true
        },
        {
          title: '操作',
          key: 'operate',
          align: 'center',
          width: '150px',
          scopedSlots: { customRender: 'action-slot' }
        }
      ]
    }
  },
  methods: {
    /**
     *  刷新表格
     */
    reloadPageTable (withFirstPage = true) {
      this.$refs.table.reloadTable(withFirstPage)
    },
    /**
     * 新建${comments}
     */
    handleAdd () {
      const attributes = { title: '新建${comments}' }
      this.$refs.formModal.add(attributes)
    },
    /**
     * 编辑${comments}
     * @param record 当前${comments}属性
     */
    handleEdit (record) {
      const attributes = { title: '编辑${comments}' }
      this.$refs.formModal.update(record, attributes)
    },
    /**
     * 删除${comments}
     * @param record 当前${comments}属性
     */
    handleDel (record) {
      doRequest(delObj(record[this.rowKey]), {
        onSuccess: () => {
          this.reloadPageTable(false)
        }
      })
    }
  }
}
</script>