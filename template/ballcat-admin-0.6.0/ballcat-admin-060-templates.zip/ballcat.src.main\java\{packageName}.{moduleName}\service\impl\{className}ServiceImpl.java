package ${packageName}.${moduleName}.service.impl;

import ${packageName}.${moduleName}.model.entity.${className};
import ${packageName}.${moduleName}.model.vo.${className}PageVO;
import ${packageName}.${moduleName}.model.qo.${className}QO;
import ${packageName}.${moduleName}.mapper.${className}Mapper;
import ${packageName}.${moduleName}.service.${className}Service;
import com.hccake.ballcat.common.model.domain.PageParam;
import com.hccake.ballcat.common.model.domain.PageResult;
import com.hccake.extend.mybatis.plus.service.impl.ExtendServiceImpl;
import org.springframework.stereotype.Service;

/**
 * ${comments}
 *
 * @author ${author} ${currentTime}
 */
@Service
public class ${className}ServiceImpl extends ExtendServiceImpl<${className}Mapper, ${className}> implements ${className}Service {

    /**
    *  根据QueryObeject查询分页数据
    * @param pageParam 分页参数
    * @param qo 查询参数对象
    * @return PageResult<${className}PageVO> 分页数据
    */
    @Override
    public PageResult<${className}PageVO> queryPage(PageParam pageParam, ${className}QO qo) {
        return baseMapper.queryPage(pageParam, qo);
    }

}
