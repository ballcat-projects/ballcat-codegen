package ${packageName}.${moduleName}.model.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;

import lombok.Data;
import java.time.LocalDateTime;

/**
 * ${comments}
 *
 * @author ${author} ${currentTime}
 */
@Data
@TableName("${tableName}")
@Schema(title = "${comments}")
public class ${className} {

	private static final long serialVersionUID = 1L;

#foreach ($column in $columns)
	/**
	 * $column.comments
	 */
#if($column.columnName == $pk.columnName)
	@TableId
#elseif($column.columnName == 'create_time')
	@TableField(fill = FieldFill.INSERT)
#elseif($column.columnName == 'update_time')
	@TableField(fill = FieldFill.INSERT_UPDATE)
#end
	@Schema(title="$column.comments")
	private $column.attrType $column.attrName;
    
#end

}
